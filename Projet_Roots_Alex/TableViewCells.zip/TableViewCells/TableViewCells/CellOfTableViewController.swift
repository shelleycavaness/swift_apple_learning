//
//  CellOfTableViewController.swift
//  TableViewCells
//
//  Created by Alexandre Bloch on 27/09/2019.
//  Copyright © 2019 Alexandre Bloch. All rights reserved.
//

import UIKit

class CellOfTableViewController: UITableViewCell {

   

}
